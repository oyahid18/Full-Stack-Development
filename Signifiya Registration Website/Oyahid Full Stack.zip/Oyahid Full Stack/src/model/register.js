// const mongoose=require("mongoose")
// const {model} = require("mongoose");
// const userData=mongoose.Schema({
//     "name":{
//         type:String,
//         require:true
//     }
//     "email":{
//         type:String,
//         require:true
//     }
//     "phone":{
//         type:String,
//         require:true
//     }
//
// })
//
// const Register= new mongoose.model("userData",userData)
// module.exports=Register
const mongoose = require("mongoose");

const userData = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    event: {
        type: String,
        required: true
    }
});

const Register = mongoose.model("userData", userData);

module.exports = Register;
